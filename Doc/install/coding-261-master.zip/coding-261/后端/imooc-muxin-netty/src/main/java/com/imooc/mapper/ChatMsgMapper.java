package com.imooc.mapper;

import com.imooc.pojo.ChatMsg;
import com.imooc.utils.MyMapper;

public interface ChatMsgMapper extends MyMapper<ChatMsg> {
}