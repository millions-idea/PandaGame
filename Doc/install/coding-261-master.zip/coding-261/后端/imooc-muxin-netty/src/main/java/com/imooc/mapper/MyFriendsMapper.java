package com.imooc.mapper;

import com.imooc.pojo.MyFriends;
import com.imooc.utils.MyMapper;

public interface MyFriendsMapper extends MyMapper<MyFriends> {
}