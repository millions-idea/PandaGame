package com.imooc.mapper;

import com.imooc.pojo.FriendsRequest;
import com.imooc.utils.MyMapper;

public interface FriendsRequestMapper extends MyMapper<FriendsRequest> {
}